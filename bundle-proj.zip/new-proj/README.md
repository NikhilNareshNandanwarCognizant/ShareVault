# Restoring GitHub Projects from Repo Bundle Files

This directory contains two Git bundle files that represent complete snapshots of GitHub repositories:

- `repo-backend.bundle`
- `repo-frontend.bundle`

A Git bundle is a single-file archive of a Git repository (commits, branches, tags, and history). You can use it to restore the full working project on any machine that has Git installed — no network or GitHub access required.

---

## Prerequisites

- **Git** must be installed and available on your `PATH`.
  Verify with:
  ```bash
  git --version
  ```
  *Prints the installed Git version. If this fails, install Git from https://git-scm.com/downloads.*

---

## 1. Verify the bundle files

Before cloning, confirm that the bundles are valid and not corrupted.

```bash
git bundle verify repo-backend.bundle
git bundle verify repo-frontend.bundle
```

*Checks that the bundle file is well-formed and lists the references (branches/tags) it contains, along with any commits it expects to already exist in the target repo. A healthy bundle prints `<file> is okay`.*

---

## 2. List the contents of a bundle (optional)

To inspect which branches/refs are packaged inside a bundle without unpacking it:

```bash
git bundle list-heads repo-backend.bundle
git bundle list-heads repo-frontend.bundle
```

*Prints each ref contained in the bundle (e.g., `refs/heads/main`, `refs/heads/develop`, tags). Useful for knowing what branches are available before cloning.*

---

## 3. Clone the repositories from the bundles

Each bundle becomes its own working Git repository when cloned.

### Backend

```bash
git clone repo-backend.bundle repo-backend
```

*Creates a new folder `repo-backend/` and restores the full backend repository — all commits, branches, and history — from the bundle.*

### Frontend

```bash
git clone repo-frontend.bundle repo-frontend
```

*Creates a new folder `repo-frontend/` and restores the full frontend repository in the same way.*

> By default, `git clone` checks out the bundle's default branch (typically `main` or `master`). You now have a normal Git working copy.

---

## 4. Enter the project and inspect it

```bash
cd repo-backend
git log --oneline -n 10
git branch -a
```

*`cd` moves into the cloned project. `git log --oneline -n 10` shows the last 10 commits in compact form. `git branch -a` lists all local and remote-tracking branches restored from the bundle.*

Repeat for the frontend:

```bash
cd ..\repo-frontend
git log --oneline -n 10
git branch -a
```

---

## 5. Check out a specific branch (if needed)

If the project uses a branch other than the default:

```bash
git checkout <branch-name>
```

*Switches your working directory to the specified branch. Use one of the names shown by `git branch -a`.*

---

## 6. Re-point the repo to GitHub (optional)

The cloned repo's `origin` remote points at the local bundle file. To push it up to a real GitHub repository:

```bash
git remote remove origin
git remote add origin https://github.com/<your-org>/<your-repo>.git
git push -u origin --all
git push origin --tags
```

*Step by step:*
- *`git remote remove origin` — detaches the repo from the local bundle file.*
- *`git remote add origin <url>` — sets the new GitHub repository as the remote.*
- *`git push -u origin --all` — uploads every local branch to GitHub and sets upstream tracking.*
- *`git push origin --tags` — uploads all tags.*

---

## 7. Install dependencies and run the projects

After cloning, treat each folder like a normal project. Common entry points:

```bash
# Backend (example — check the repo's own README)
cd repo-backend
npm install        # or: pip install -r requirements.txt, mvn install, etc.
npm run start

# Frontend
cd ..\repo-frontend
npm install
npm run dev
```

*`npm install` (or the language equivalent) downloads project dependencies. `npm run start` / `npm run dev` launches the application. The exact commands depend on each project's own `README` and `package.json` / build config.*

---

## Troubleshooting

| Problem | Likely cause | Fix |
|---|---|---|
| `error: Repository lacks these prerequisite commits` | Bundle is a *partial* bundle that expects an existing repo. | Clone into an existing repo with `git fetch <bundle-path>` instead of `git clone`. |
| `fatal: '<bundle>' does not appear to be a git repository` | Wrong file path or corrupted bundle. | Re-run `git bundle verify <bundle>` and check the path. |
| `git: command not found` | Git is not installed or not on PATH. | Install Git from https://git-scm.com/downloads and reopen the terminal. |

---

## Quick reference

```bash
git bundle verify repo-backend.bundle      # validate
git bundle list-heads repo-backend.bundle  # peek at refs
git clone repo-backend.bundle repo-backend # restore project
cd repo-backend && git log --oneline       # confirm history
```

Repeat the same flow for `repo-frontend.bundle`.
