# meraProj — Git Mirror Access Guide

This folder contains **bare Git mirror clones** of two GitHub repositories. A mirror is a complete, server-style copy of a repo — it has no working tree (no checked-out source files you can edit directly), but it holds every branch, tag, and commit from the origin.

## What's in this folder

| Mirror directory | Origin repository |
| --- | --- |
| `angularFrontendUnderwritePro.git` | https://github.com/NikhilNareshNandanwarCognizant/angularFrontendUnderwritePro.git |
| `UnderwritePro.git` | https://github.com/NikhilNareshNandanwarCognizant/UnderwritePro.git |

Both were created with `git clone --mirror`, so each `.git` directory contains:

- `HEAD` — pointer to the default branch (`refs/heads/main`).
- `config` — stores the `origin` URL and `mirror = true` flag.
- `refs/` and `packed-refs` — all branch and tag references.
- `objects/` — every commit, tree, and blob in the repo's history.
- `hooks/`, `info/`, `description/` — standard Git internals.

You **cannot** browse source files directly inside these directories — the content is stored as packed Git objects, not regular files. You need to either clone a working copy out of the mirror, or check files out from it.

---

## 1. Inspect a mirror without checking anything out

Run any of these from the parent folder (`meraProj`). Replace the path with whichever mirror you want.

```powershell
# List every branch and tag stored in the mirror
git --git-dir=UnderwritePro.git branch -a
git --git-dir=UnderwritePro.git tag

# Show the most recent commits on the default branch
git --git-dir=UnderwritePro.git log --oneline -20

# Show which remote URL this mirror points to on GitHub
git --git-dir=UnderwritePro.git remote -v

# Read a single file from a specific branch without checking it out
git --git-dir=UnderwritePro.git show main:path/to/file.ext
```

`--git-dir=<path>` tells Git "treat this folder as the repo" instead of looking for a `.git` next to your current working directory. This is how you talk to a bare repo.

---

## 2. Get a normal, browsable working copy out of the mirror

The mirror is the source of truth locally. To get editable files, clone *from the mirror* into a new sibling folder:

```powershell
# Clone the bare mirror into a regular working repo
git clone angularFrontendUnderwritePro.git angularFrontendUnderwritePro
git clone UnderwritePro.git UnderwritePro
```

After this you'll have two new folders (`angularFrontendUnderwritePro/` and `UnderwritePro/`) containing the actual source code, with `main` checked out. You can `cd` into either and use Git normally (`git status`, `git checkout <branch>`, `git log`, etc.).

> **Why clone from the local mirror instead of GitHub directly?** It's faster (no network), it works offline, and it guarantees you're seeing exactly what the mirror snapshot captured.

After cloning, the new working copy's `origin` will point at the local mirror path. If you want it to point at GitHub instead so you can `push`/`pull` against the real repo, reset it:

```powershell
# Switch the working copy's origin to the real GitHub URL
cd UnderwritePro
git remote set-url origin https://github.com/NikhilNareshNandanwarCognizant/UnderwritePro.git
git remote -v   # verify the change
```

---

## 3. Update the mirror from GitHub

Mirrors go stale. To pull every new branch, tag, and commit from GitHub into the local mirror:

```powershell
git --git-dir=UnderwritePro.git remote update --prune
git --git-dir=angularFrontendUnderwritePro.git remote update --prune
```

- `remote update` fetches all refs from `origin` (because the repo was cloned with `--mirror`, this includes branches, tags, and notes — not just `main`).
- `--prune` deletes local refs for branches/tags that were removed on GitHub, keeping the mirror in sync rather than letting deleted branches linger.

You'll need network access and credentials with read access to those GitHub repos for this to succeed.

---

## 4. Push the mirror back to GitHub (or to a new remote)

If you ever need to restore one of these repos to GitHub from this folder — for example, after an accidental deletion — push the mirror back:

```powershell
git --git-dir=UnderwritePro.git push --mirror origin
```

`push --mirror` is the inverse of `clone --mirror`: it sends **every** local ref to the remote and deletes remote refs that don't exist locally. It will overwrite the remote, so only use it intentionally for restore/migration scenarios.

To migrate to a different GitHub URL (e.g., a fork or a new org), point `origin` at the new URL first, then mirror-push:

```powershell
git --git-dir=UnderwritePro.git remote set-url origin https://github.com/<new-owner>/<new-repo>.git
git --git-dir=UnderwritePro.git push --mirror origin
```

---

## 5. Open the project on GitHub directly

The fastest path to the live project (issues, PRs, README rendered, etc.) is just the browser:

- https://github.com/NikhilNareshNandanwarCognizant/UnderwritePro
- https://github.com/NikhilNareshNandanwarCognizant/angularFrontendUnderwritePro

These URLs come from each mirror's `config` file under `[remote "origin"]`.

---

## Quick command reference

| Goal | Command |
| --- | --- |
| See origin URL | `git --git-dir=<mirror>.git remote -v` |
| List branches | `git --git-dir=<mirror>.git branch -a` |
| List tags | `git --git-dir=<mirror>.git tag` |
| Recent history | `git --git-dir=<mirror>.git log --oneline -20` |
| Read one file | `git --git-dir=<mirror>.git show main:<path>` |
| Get working copy | `git clone <mirror>.git <folder-name>` |
| Refresh from GitHub | `git --git-dir=<mirror>.git remote update --prune` |
| Restore to GitHub | `git --git-dir=<mirror>.git push --mirror origin` |
